﻿window.TasksInterop = {

    component: null,

    setComponent: function (ref) {
        this.component = ref;
    },

    bindRowEventsById: function (id) {
        const cell = document.getElementById("task-name-" + id);
        if (!cell) return;

        // ПКМ → удалить
        cell.addEventListener("contextmenu", e => {
            e.preventDefault();
            window.TasksInterop.confirmDelete(id);
        });

        // ЛКМ → переименовать
        cell.addEventListener("click", e => {
            let value = prompt("Новое имя:");
            if (value)
                DotNet.invokeMethodAsync("Tasks_app", "RequestTaskRename", id, value);
        });
    },

    confirmDelete: function (id) {
        const dlg = document.getElementById("task-delete-dialog");

        const yes = document.getElementById("task-del-yes");
        const no = document.getElementById("task-del-no");

        dlg.style.display = "flex";

        yes.replaceWith(yes.cloneNode(true));
        no.replaceWith(no.cloneNode(true));

        const yes2 = document.getElementById("task-del-yes");
        const no2 = document.getElementById("task-del-no");

        yes2.addEventListener("click", () => {
            dlg.style.display = "none";
            DotNet.invokeMethodAsync("Tasks_app", "RequestTaskDelete", id);
        });

        no2.addEventListener("click", () => {
            dlg.style.display = "none";
        });
    }
};
